from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
# Create your views here
def index(request):
    return render(request,'welcome.html')

def loginpage(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('about')  # Redirect to the about page upon successful login
        else:
            messages.error(request, "Invalid username or password")
    return render(request, 'login.html')


def signup(request):
    if request.method == "POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm-password')
        
        if password != confirm_password:
            messages.error(request, "Passwords do not match")
            return redirect('signup')
        
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists")
            return redirect('signup')
        
        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered")
            return redirect('signup')
        
        # Create the user
        User.objects.create_user(username=username, email=email, password=password)
        messages.success(request, "Account created successfully! Please log in.")
        return redirect('loginpage')
    
    return render(request, 'sign.html')
@login_required
def about(request):
    return render(request,'about.html')

def men(request):
    return render(request, 'men.html')

def women(request):
    return render(request, 'women.html')

def shirt(request):
    return render(request, 'shirt.html')

def  ethenic(request):
    return render(request, 'ethenic.html')

def  top(request):
    return render(request, 'top.html')

def  footwear(request):
    return render(request, 'footwear.html')

def  shoe(request):
    return render(request, 'shoe.html')

def  pant(request):
    return render(request, 'pant.html')

def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out successfully")
    return redirect('loginpage')







